package com.example.clubmgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClubmgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
