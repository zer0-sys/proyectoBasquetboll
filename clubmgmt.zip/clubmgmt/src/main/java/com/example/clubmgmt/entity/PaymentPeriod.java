package com.example.clubmgmt.entity;

public enum PaymentPeriod {
    WEEKLY,     // Semanal
    BIWEEKLY,   // Quincenal
    MONTHLY     // Mensual
}