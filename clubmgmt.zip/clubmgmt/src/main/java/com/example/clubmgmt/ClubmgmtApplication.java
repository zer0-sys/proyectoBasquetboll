package com.example.clubmgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClubmgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClubmgmtApplication.class, args);
	}

}
